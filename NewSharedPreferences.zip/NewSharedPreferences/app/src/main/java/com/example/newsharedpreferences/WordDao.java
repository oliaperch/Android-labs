package com.example.newsharedpreferences;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;

import java.util.List;

@Dao
public interface WordDao {
    //додати елемент
    @Insert(onConflict = OnConflictStrategy.IGNORE) //у випадку конфлікту будемо ігнорувати
    void insert(Word word);

    //витерти всю інформацію
    @Query("DELETE from word_table")
    void deleteAll();

    //Кожен елемент списку - це екземпляр класу Word
    @Query("SELECT * from word_table ORDER BY word ASC")
    LiveData<List<Word>> getAllWords(); //додали LiveData

    @Query("SELECT * from word_table LIMIT 1")
    Word[] getAnyWord();

    @Delete
    void deleteWord(Word word);
}
