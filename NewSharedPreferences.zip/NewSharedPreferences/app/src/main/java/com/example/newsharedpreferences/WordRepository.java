package com.example.newsharedpreferences;

import android.app.Application;
import android.os.AsyncTask;

import androidx.lifecycle.LiveData;

import java.util.List;

public class WordRepository {
    private WordDao mWordDao;
    private LiveData<List<Word>> mAllWords;

    //ініціалізуємо нашу БД
    WordRepository(Application application) {
        WordRoomDatabase db = WordRoomDatabase.getDatabase(application); //перевіряємо наявність
        mWordDao = db.wordDao();
        mAllWords = mWordDao.getAllWords(); //зчитуємо дані у буфер
    }

    LiveData<List<Word>> getAllWords() {
        return mAllWords;
    }

    //додаємо елементи
    public void insert (Word word) {
        new insertAsyncTask(mWordDao).execute(word);
    }

    //у фоновому режимі запускає виклик методу із класу DataAsyncObject
    private static class insertAsyncTask extends AsyncTask<Word, Void, Void> {

        private WordDao mAsyncTaskDao;

        insertAsyncTask(WordDao dao) {
            mAsyncTaskDao = dao;
        }

        @Override
        protected Void doInBackground(final Word... params) {
            mAsyncTaskDao.insert(params[0]);
            return null;
        }
    }

    //модифікація, Part B
    private static class deleteAllWordsAsyncTask extends AsyncTask<Void, Void, Void> {
        private WordDao mAsyncTaskDao;

        deleteAllWordsAsyncTask(WordDao dao) {
            mAsyncTaskDao = dao;
        }

        @Override
        protected Void doInBackground(Void... voids) {
            mAsyncTaskDao.deleteAll();
            return null;
        }
    }

    public void deleteAll()  {
        new deleteAllWordsAsyncTask(mWordDao).execute();
    }

    private static class deleteWordAsyncTask extends AsyncTask<Word, Void, Void> {
        private WordDao mAsyncTaskDao;

        deleteWordAsyncTask(WordDao dao) {
            mAsyncTaskDao = dao;
        }

        @Override
        protected Void doInBackground(final Word... params) {
            mAsyncTaskDao.deleteWord(params[0]);
            return null;
        }
    }

    //method to invoke the AsyncTask you defined
    public void deleteWord(Word word)  {
        new deleteWordAsyncTask(mWordDao).execute(word);
    }
}
